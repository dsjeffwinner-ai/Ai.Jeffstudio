import express from "express";
import dotenv from "dotenv";
import path from "node:path";
import { fileURLToPath } from "node:url";

dotenv.config();
const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const XAI_API_KEY = process.env.XAI_API_KEY;
const XAI_BASE = "https://api.x.ai/v1";
app.use(express.json({ limit: "11mb" }));
app.use(express.static(path.join(__dirname, "public")));

function safeError(data, fallback) {
  return data?.error?.message || data?.message || fallback;
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, providerConfigured: Boolean(XAI_API_KEY) });
});

app.post("/api/generate", async (req, res) => {
  if (!XAI_API_KEY) return res.status(503).json({ error: "Video service is not configured yet. Add XAI_API_KEY to your host's environment variables." });
  const { image, prompt, style, camera, duration, resolution } = req.body || {};
  if (typeof image !== "string" || !/^data:image\/(png|jpeg|webp);base64,/i.test(image)) {
    return res.status(400).json({ error: "Please upload a PNG, JPEG, or WebP image." });
  }
  if (image.length > 10_800_000) return res.status(413).json({ error: "Image is too large. Please use an image under 8 MB." });
  if (typeof prompt !== "string" || !prompt.trim() || prompt.length > 1500) {
    return res.status(400).json({ error: "Enter a prompt between 1 and 1500 characters." });
  }
  const seconds = Number(duration);
  if (![5, 10, 12, 15].includes(seconds)) return res.status(400).json({ error: "Choose a supported duration: 5, 10, 12, or 15 seconds." });
  const allowedResolutions = ["720p", "1080p"];
  const safeResolution = allowedResolutions.includes(resolution) ? resolution : "720p";
  const combinedPrompt = [
    prompt.trim(),
    style ? `Visual style: ${String(style).slice(0, 80)}.` : "",
    camera ? `Camera movement: ${String(camera).slice(0, 80)}.` : ""
  ].filter(Boolean).join(" ");

  try {
    const upstream = await fetch(`${XAI_BASE}/videos/generations`, {
      method: "POST",
      headers: { "Authorization": `Bearer ${XAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "grok-imagine-video-1.5",
        prompt: combinedPrompt,
        image: { url: image },
        duration: seconds,
        resolution: safeResolution
      })
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("xAI generation request failed:", upstream.status, data);
      return res.status(upstream.status >= 400 && upstream.status < 500 ? upstream.status : 502)
        .json({ error: safeError(data, `Video provider request failed (HTTP ${upstream.status}). Check your API access and billing.`) });
    }
    if (!data.request_id) return res.status(502).json({ error: "Video provider did not return a request ID." });
    return res.json({ requestId: data.request_id });
  } catch (err) {
    console.error("Generation request error:", err);
    return res.status(502).json({ error: "Could not reach the video provider. Check your server's internet access and try again." });
  }
});

app.get("/api/status/:requestId", async (req, res) => {
  if (!XAI_API_KEY) return res.status(503).json({ error: "Video service is not configured." });
  const requestId = req.params.requestId;
  if (!/^[A-Za-z0-9_-]{8,100}$/.test(requestId)) return res.status(400).json({ error: "Invalid generation request ID." });
  try {
    const upstream = await fetch(`${XAI_BASE}/videos/${encodeURIComponent(requestId)}`, {
      headers: { "Authorization": `Bearer ${XAI_API_KEY}` }
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("xAI status check failed:", upstream.status, data);
      return res.status(502).json({ error: safeError(data, "Could not check video status.") });
    }
    if (data.status === "done") return res.json({ status: "done", videoUrl: data.video?.url || null });
    if (data.status === "failed") return res.json({ status: "failed", error: data.error || "The provider could not generate this video." });
    return res.json({ status: data.status || "processing" });
  } catch (err) {
    console.error("Status check error:", err);
    return res.status(502).json({ error: "Could not check generation status. Try again shortly." });
  }
});

app.listen(PORT, () => console.log(`AI.JEFFStudio backend listening on port ${PORT}`));
