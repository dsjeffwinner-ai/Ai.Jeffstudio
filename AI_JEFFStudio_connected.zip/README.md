AI.JEFFStudio — connected video-generation starter
===================================================

This project keeps the original one-page interface and connects the Create button to xAI's image-to-video API through a small Node.js/Express backend.

IMPORTANT
- This is integration code, not a deployed website. It will not generate videos until you deploy it and configure an xAI API key.
- Never put your API key in public/index.html or send it in chat.
- Video generations are paid/usage-metered according to your provider account. Review pricing and limits before generating.
- Uploaded images are sent to the video provider for processing. Do not upload images you do not have permission to use.

LOCAL SETUP
1. Install Node.js 20 or newer.
2. In this folder, run: npm install
3. Copy .env.example to .env.
4. Add your key to .env as XAI_API_KEY=your_key_here (on your own computer only).
5. Run: npm start
6. Open http://localhost:3000

DEPLOYMENT
Deploy this whole project to a Node.js host that supports server-side environment variables, such as Render or Railway. Do not deploy only the HTML file to a static-only host.
- Build/install command: npm install
- Start command: npm start
- Add XAI_API_KEY in the host's Environment Variables / Secrets settings.
- The host should run Node.js 20+ and expose the assigned PORT.
- Do not commit .env to source control.

API
- GET /api/health — basic health and configuration status (does not reveal the key).
- POST /api/generate — starts a generation and returns requestId.
- GET /api/status/:requestId — checks provider status and returns videoUrl when done.

LIMITATIONS
- This starter uses xAI model grok-imagine-video-1.5. Availability, pricing, image sizes, resolutions, and duration limits can change; verify your xAI account and official docs.
- The UI offers 5, 10, 12, and 15 seconds. The 30-second option from the original prototype was removed because the image-to-video integration should only expose supported short durations.
- The provider returns a video URL. The link may be temporary; save completed videos to your own storage for a production service.
- Before public launch, add user authentication, per-user rate limits, quotas, abuse prevention, request logging that excludes private images/secrets, and storage/retention controls.
